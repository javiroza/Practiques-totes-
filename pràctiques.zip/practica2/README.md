# practica2
Física Computacional - Pràctica 2
